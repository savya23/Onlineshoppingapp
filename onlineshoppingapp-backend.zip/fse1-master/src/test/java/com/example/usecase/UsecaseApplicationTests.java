package com.example.usecase;

import org.junit.jupiter.api.Test;
class UsecaseApplicationTests {

	@Test
	void contextLoads() {
	}

}
